import os, secrets, base64
from passlib.hash import bcrypt
from itsdangerous import TimestampSigner, BadSignature, SignatureExpired

SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me")
signer = TimestampSigner(SECRET_KEY)

def hash_password(pw: str) -> str:
    return bcrypt.hash(pw)

def verify_password(pw: str, pw_hash: str) -> bool:
    try:
        return bcrypt.verify(pw, pw_hash)
    except Exception:
        return False

def create_session(data: str) -> str:
    return signer.sign(data.encode()).decode()

def verify_session(token: str) -> str | None:
    try:
        raw = signer.unsign(token, max_age=60*60*24*14)  # 14 days
        return raw.decode()
    except (BadSignature, SignatureExpired):
        return None
