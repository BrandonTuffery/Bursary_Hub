from sqlalchemy.orm import Session
from .models import User
from .utils import hash_password

def ensure_admin(db: Session):
    admin = db.query(User).filter(User.email=="admin@bursaryhub.local").first()
    if not admin:
        admin = User(email="admin@bursaryhub.local", password_hash=hash_password("Admin123!"), role="staff")
        db.add(admin)
        db.commit()
