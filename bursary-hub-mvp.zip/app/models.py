from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Enum, Text, Boolean, Float
from sqlalchemy.orm import relationship, declarative_base

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(String, default="student")  # 'student' or 'staff'
    created_at = Column(DateTime, default=datetime.utcnow)

    applications = relationship("Application", back_populates="user")

class Application(Base):
    __tablename__ = "applications"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    status = Column(String, default="draft")  # draft, submitted, in_review, approved, rejected, needs_more_info
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)

    # Example eligibility fields (simplified)
    household_income = Column(Integer, nullable=True)
    vulnerable_group = Column(Boolean, default=False)
    caring_responsibilities = Column(Boolean, default=False)
    travel_support_needed = Column(Boolean, default=False)
    equipment_needed = Column(Boolean, default=False)
    childcare_needed = Column(Boolean, default=False)
    course_hours_per_week = Column(Integer, nullable=True)
    statement = Column(Text, default="")

    user = relationship("User", back_populates="applications")
    documents = relationship("Document", back_populates="application", cascade="all, delete-orphan")
    payments = relationship("Payment", back_populates="application", cascade="all, delete-orphan")
    audits = relationship("Audit", back_populates="application", cascade="all, delete-orphan")

class Document(Base):
    __tablename__ = "documents"
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey("applications.id"), nullable=False)
    kind = Column(String)  # e.g., 'household_income', 'id', 'childcare_invoice'
    filename = Column(String)
    stored_path = Column(String)
    uploaded_at = Column(DateTime, default=datetime.utcnow)

    application = relationship("Application", back_populates="documents")

class Payment(Base):
    __tablename__ = "payments"
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey("applications.id"), nullable=False)
    label = Column(String)  # e.g., 'Autumn term instalment'
    amount = Column(Float, default=0.0)
    scheduled_date = Column(DateTime, default=datetime.utcnow)
    status = Column(String, default="scheduled")  # scheduled, sent, failed, cancelled
    created_at = Column(DateTime, default=datetime.utcnow)

    application = relationship("Application", back_populates="payments")

class Audit(Base):
    __tablename__ = "audits"
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey("applications.id"), nullable=False)
    actor_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String)  # submitted, status_change, doc_upload, comment
    details = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

    application = relationship("Application", back_populates="audits")
