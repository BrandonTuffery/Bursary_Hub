import os
from datetime import datetime
from fastapi import FastAPI, Request, Form, UploadFile, File, Depends
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from .db import SessionLocal
from .models import Base, User, Application, Document, Payment, Audit
from .utils import hash_password, verify_password, create_session, verify_session
from .bootstrap import ensure_admin

app = FastAPI(title="Bursary Hub")
app.mount("/static", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(os.path.dirname(__file__), "templates"))

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# DB init
from sqlalchemy import create_engine
from .db import engine
Base.metadata.create_all(engine)

# seed admin
with SessionLocal() as db:
    ensure_admin(db)

# Helper: current user from cookie
def current_user(request: Request, db: Session):
    token = request.cookies.get("session")
    if not token:
        return None
    email = verify_session(token)
    if not email:
        return None
    return db.query(User).filter(User.email==email).first()

@app.get("/", response_class=HTMLResponse)
def home(request: Request, db: Session = Depends(get_db)):
    user = current_user(request, db)
    return templates.TemplateResponse("home.html", {"request": request, "user": user})

@app.post("/signup")
def signup(email: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    if db.query(User).filter(User.email==email).first():
        return RedirectResponse("/?err=exists", status_code=303)
    u = User(email=email, password_hash=hash_password(password))
    db.add(u); db.commit()
    resp = RedirectResponse("/dashboard", status_code=303)
    resp.set_cookie("session", create_session(email), httponly=True, samesite="lax")
    return resp

@app.post("/login")
def login(email: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    u = db.query(User).filter(User.email==email).first()
    if not u or not verify_password(password, u.password_hash):
        return RedirectResponse("/?err=login", status_code=303)
    resp = RedirectResponse("/dashboard", status_code=303)
    resp.set_cookie("session", create_session(email), httponly=True, samesite="lax")
    return resp

@app.get("/logout")
def logout():
    resp = RedirectResponse("/", status_code=303)
    resp.delete_cookie("session")
    return resp

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request, db: Session = Depends(get_db)):
    user = current_user(request, db)
    if not user:
        return RedirectResponse("/", status_code=303)
    apps = db.query(Application).filter(Application.user_id==user.id).all() if user.role=="student" else            db.query(Application).order_by(Application.created_at.desc()).all()
    return templates.TemplateResponse("dashboard.html", {"request": request, "user": user, "apps": apps})

@app.post("/application/create")
def create_application(request: Request, db: Session = Depends(get_db)):
    user = current_user(request, db)
    if not user:
        return RedirectResponse("/", status_code=303)
    appn = Application(user_id=user.id, status="draft")
    db.add(appn); db.commit()
    return RedirectResponse(f"/application/{appn.id}/edit", status_code=303)

@app.get("/application/{app_id}/edit", response_class=HTMLResponse)
def edit_application(app_id: int, request: Request, db: Session = Depends(get_db)):
    user = current_user(request, db)
    if not user: return RedirectResponse("/", status_code=303)
    appn = db.query(Application).get(app_id)
    if not appn or (user.role=="student" and appn.user_id != user.id):
        return Response("Not found", status_code=404)
    return templates.TemplateResponse("application_edit.html", {"request": request, "user": user, "app": appn})

@app.post("/application/{app_id}/save")
def save_application(app_id: int,
                     household_income: int = Form(None),
                     vulnerable_group: int = Form(0),
                     caring_responsibilities: int = Form(0),
                     travel_support_needed: int = Form(0),
                     equipment_needed: int = Form(0),
                     childcare_needed: int = Form(0),
                     course_hours_per_week: int = Form(None),
                     statement: str = Form(""),
                     db: Session = Depends(get_db),
                     request: Request = None):
    user = current_user(request, db)
    if not user: return RedirectResponse("/", status_code=303)
    appn = db.query(Application).get(app_id)
    if not appn or (user.role=="student" and appn.user_id != user.id):
        return Response("Not found", status_code=404)
    appn.household_income = household_income
    appn.vulnerable_group = bool(vulnerable_group)
    appn.caring_responsibilities = bool(caring_responsibilities)
    appn.travel_support_needed = bool(travel_support_needed)
    appn.equipment_needed = bool(equipment_needed)
    appn.childcare_needed = bool(childcare_needed)
    appn.course_hours_per_week = course_hours_per_week
    appn.statement = statement
    appn.updated_at = datetime.utcnow()
    db.add(appn); db.commit()
    db.add(Audit(application_id=appn.id, action="save", details="Saved application"))
    db.commit()
    return RedirectResponse(f"/application/{appn.id}/edit?ok=1", status_code=303)

@app.post("/application/{app_id}/submit")
def submit_application(app_id: int, db: Session = Depends(get_db), request: Request = None):
    user = current_user(request, db)
    if not user: return RedirectResponse("/", status_code=303)
    appn = db.query(Application).get(app_id)
    if not appn or (user.role=="student" and appn.user_id != user.id):
        return Response("Not found", status_code=404)
    appn.status = "submitted"; appn.updated_at = datetime.utcnow()
    db.add(appn); db.add(Audit(application_id=appn.id, action="submitted", details="Student submitted")); db.commit()
    print(f"[EMAIL] Application #{appn.id} submitted by {user.email}")
    return RedirectResponse("/dashboard", status_code=303)

@app.post("/application/{app_id}/upload")
def upload_document(app_id: int, kind: str = Form("other"), file: UploadFile = File(...),
                    db: Session = Depends(get_db), request: Request = None):
    user = current_user(request, db)
    if not user: return RedirectResponse("/", status_code=303)
    appn = db.query(Application).get(app_id)
    if not appn or (user.role=="student" and appn.user_id != user.id):
        return Response("Not found", status_code=404)
    upload_dir = os.path.join(os.path.dirname(__file__), "uploads", str(appn.id))
    os.makedirs(upload_dir, exist_ok=True)
    dest_path = os.path.join(upload_dir, file.filename)
    with open(dest_path, "wb") as f:
        f.write(file.file.read())
    doc = Document(application_id=appn.id, kind=kind, filename=file.filename, stored_path=dest_path)
    db.add(doc); db.add(Audit(application_id=appn.id, action="doc_upload", details=kind)); db.commit()
    return RedirectResponse(f"/application/{appn.id}/edit?uploaded=1", status_code=303)

# Staff actions
@app.get("/admin/applications", response_class=HTMLResponse)
def admin_list(request: Request, db: Session = Depends(get_db)):
    user = current_user(request, db)
    if not user or user.role != "staff":
        return RedirectResponse("/", status_code=303)
    apps = db.query(Application).order_by(Application.created_at.desc()).all()
    return templates.TemplateResponse("admin_list.html", {"request": request, "user": user, "apps": apps})

@app.get("/admin/application/{app_id}", response_class=HTMLResponse)
def admin_view(app_id: int, request: Request, db: Session = Depends(get_db)):
    user = current_user(request, db)
    if not user or user.role != "staff":
        return RedirectResponse("/", status_code=303)
    appn = db.query(Application).get(app_id)
    if not appn: return Response("Not found", status_code=404)
    return templates.TemplateResponse("admin_view.html", {"request": request, "user": user, "app": appn})

@app.post("/admin/application/{app_id}/status")
def admin_status(app_id: int, status: str = Form(...), db: Session = Depends(get_db), request: Request = None):
    user = current_user(request, db)
    if not user or user.role != "staff":
        return RedirectResponse("/", status_code=303)
    appn = db.query(Application).get(app_id)
    if not appn: return Response("Not found", status_code=404)
    appn.status = status; appn.updated_at = datetime.utcnow()
    db.add(appn); db.add(Audit(application_id=appn.id, actor_id=user.id, action="status_change", details=status)); db.commit()
    print(f"[EMAIL] Application #{appn.id} status changed to {status}")
    return RedirectResponse(f"/admin/application/{appn.id}", status_code=303)

@app.post("/admin/application/{app_id}/payment")
def admin_payment(app_id: int, label: str = Form("Instalment"), amount: float = Form(0.0),
                  db: Session = Depends(get_db), request: Request = None):
    user = current_user(request, db)
    if not user or user.role != "staff":
        return RedirectResponse("/", status_code=303)
    appn = db.query(Application).get(app_id)
    if not appn: return Response("Not found", status_code=404)
    p = Payment(application_id=appn.id, label=label, amount=amount, status="scheduled")
    db.add(p); db.add(Audit(application_id=appn.id, actor_id=user.id, action="payment_add", details=f"{label}:{amount}")); db.commit()
    return RedirectResponse(f"/admin/application/{appn.id}", status_code=303)
