# Bursary Hub (MVP)

A minimal bursary portal inspired by PayMyStudent-style workflows. Built with **FastAPI + SQLite + Jinja2**.

## Features in this MVP
- Student sign up, login, and dashboard
- Eligibility questionnaire (16–19 style example)
- Document upload (household income, ID, etc.)
- Status tracking: Draft → Submitted → In Review → Approved/Rejected
- Admin/staff panel: filter, view application, request more info, approve/reject
- Simple payments log placeholder (records intended bursary instalments, not real payments)
- Email/notifications via console logging
- Audit trail: actions on applications
- Basic RBAC (student/staff)
- GOV.UK-style terms links placeholder

> This is a teaching/demo build – not production ready. Add SSO, strong security, cloud storage, proper email, and attendance integrations before real use.

## Quick start
1. Create a virtualenv and install deps:
   ```bash
   python -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   ```
2. Run the app:
   ```bash
   uvicorn app.main:app --reload
   ```
3. Open http://127.0.0.1:8000

### Default staff account
- Email: `admin@bursaryhub.local`
- Password: `Admin123!`

You can change this in `app/bootstrap.py`.

## Tech choices
- FastAPI (API + server-rendered pages)
- Jinja2 templates with Bootstrap 5
- SQLite via SQLAlchemy
- Simple session auth using signed cookies

## Next steps (suggested)
- Replace sessions with OAuth/SSO (e.g. Microsoft Entra ID)
- Uploads to S3/Azure Blob; virus scanning
- Attendance data feed integration
- Real payment rails or export to finance
- Accessibility review (WCAG 2.2 AA)
- Full audit & GDPR DSR tooling
